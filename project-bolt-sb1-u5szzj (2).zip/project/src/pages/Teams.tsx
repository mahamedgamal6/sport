import { Star, Plus, Users, Trophy, Shield } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Link } from 'react-router-dom';

interface Team {
  id: number;
  name: string;
  imageUrl: string;
  playerCount: number;
  rating: number;
  league: string;
  founded: string;
}

const teams: Team[] = [
  {
    id: 1,
    name: "Liverpool FC",
    imageUrl: "https://images.unsplash.com/photo-1623796898129-f0df61d5c587?w=800&auto=format&fit=crop&q=60",
    playerCount: 28,
    rating: 5,
    league: "Premier League",
    founded: "1892"
  },
  {
    id: 2,
    name: "Manchester United",
    imageUrl: "https://images.unsplash.com/photo-1599204606395-ede920a0c117?w=800&auto=format&fit=crop&q=60",
    playerCount: 26,
    rating: 4,
    league: "Premier League",
    founded: "1878"
  },
  {
    id: 3,
    name: "Real Madrid",
    imageUrl: "https://images.unsplash.com/photo-1629627562337-eb6be89e8c80?w=800&auto=format&fit=crop&q=60",
    playerCount: 27,
    rating: 5,
    league: "La Liga",
    founded: "1902"
  },
  {
    id: 4,
    name: "Bayern Munich",
    imageUrl: "https://images.unsplash.com/photo-1577223625816-7546f13df25d?w=800&auto=format&fit=crop&q=60",
    playerCount: 25,
    rating: 5,
    league: "Bundesliga",
    founded: "1900"
  },
  {
    id: 5,
    name: "Paris Saint-Germain",
    imageUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=800&auto=format&fit=crop&q=60",
    playerCount: 24,
    rating: 4,
    league: "Ligue 1",
    founded: "1970"
  }
];

export function Teams() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-900 to-black">
      {/* Header Section */}
      <div className="relative h-[300px] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=60"
            alt="Stadium"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-navy-900/50 to-navy-900"></div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-4xl font-bold text-white mb-2">Teams</h1>
            <p className="text-gray-300 text-lg">Discover and manage professional football teams</p>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="max-w-7xl mx-auto px-4 -mt-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard icon={Shield} title="Total Teams" value="5" />
          <StatsCard icon={Users} title="Total Players" value="130" />
          <StatsCard icon={Trophy} title="Trophies" value="247" />
        </div>
      </div>

      {/* Teams Grid */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Add Team Card */}
          <button className="group relative h-[300px] rounded-2xl border-2 border-dashed border-yellow-500/30 bg-navy-900/50 p-6 transition-all hover:border-yellow-500/60 hover:bg-navy-900/70">
            <div className="flex h-full flex-col items-center justify-center space-y-4">
              <div className="rounded-full bg-yellow-500/10 p-4 group-hover:bg-yellow-500/20 transition-colors">
                <Plus className="h-8 w-8 text-yellow-500" />
              </div>
              <span className="text-lg font-medium text-yellow-500">Add New Team</span>
            </div>
          </button>

          {/* Team Cards */}
          {teams.map((team) => (
            <TeamCard key={team.id} team={team} />
          ))}
        </div>
      </div>
    </div>
  );
}

function StatsCard({ icon: Icon, title, value }: { icon: any; title: string; value: string }) {
  return (
    <div className="bg-navy-900/90 rounded-xl p-6 border border-yellow-500/20 backdrop-blur-sm">
      <div className="flex items-center space-x-4">
        <div className="p-3 bg-yellow-500/10 rounded-lg">
          <Icon className="h-6 w-6 text-yellow-500" />
        </div>
        <div>
          <p className="text-sm text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
        </div>
      </div>
    </div>
  );
}

function TeamCard({ team }: { team: Team }) {
  return (
    <div className="group relative bg-navy-900/90 rounded-2xl overflow-hidden border border-yellow-500/20 transition-all hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/10">
      {/* Team Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={team.imageUrl}
          alt={team.name}
          className="w-full h-full object-cover transition-transform group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-transparent to-transparent"></div>
      </div>

      {/* Team Info */}
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-white">{team.name}</h3>
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < team.rating ? 'text-yellow-500' : 'text-gray-600'
                }`}
                fill={i < team.rating ? 'currentColor' : 'none'}
              />
            ))}
          </div>
        </div>

        <div className="space-y-2 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">League</span>
            <span className="text-white">{team.league}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Founded</span>
            <span className="text-white">{team.founded}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Squad Size</span>
            <span className="text-white">{team.playerCount} players</span>
          </div>
        </div>

        <div className="flex justify-between items-center">
          <Link to={`/teams/${team.id}`}>
            <Button
              variant="outline"
              size="sm"
              className="border-yellow-500/20 hover:bg-yellow-500/10 text-yellow-500"
            >
              View Details
            </Button>
          </Link>
          <Button
            size="sm"
            className="bg-yellow-500 hover:bg-yellow-600 text-black"
          >
            Join Team
          </Button>
        </div>
      </div>
    </div>
  );
}