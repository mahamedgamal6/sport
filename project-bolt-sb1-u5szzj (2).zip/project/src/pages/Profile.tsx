import { useState } from 'react';
import { Trophy, Medal, Star, Activity, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/lib/store';

interface Stats {
  goals: number;
  assists: number;
  matches: number;
  wins: number;
}

interface Achievement {
  id: string;
  title: string;
  date: string;
  icon: JSX.Element;
}

export function Profile() {
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'stats' | 'achievements'>('overview');

  const stats: Stats = {
    goals: 45,
    assists: 28,
    matches: 120,
    wins: 78,
  };

  const achievements: Achievement[] = [
    { id: '1', title: 'League Champion 2023', date: '2023-12-15', icon: <Trophy className="h-6 w-6 text-yellow-400" /> },
    { id: '2', title: 'Top Scorer', date: '2023-11-30', icon: <Medal className="h-6 w-6 text-green-400" /> },
    { id: '3', title: 'MVP of the Season', date: '2023-10-20', icon: <Star className="h-6 w-6 text-blue-400" /> },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <div className="bg-gray-900 rounded-xl p-8 mb-8 border border-green-500/20">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1628891890467-b79de80b8c1f?w=200&h=200&fit=crop"
              alt="Profile"
              className="w-32 h-32 rounded-full object-cover border-4 border-green-500"
            />
            <span className="absolute bottom-0 right-0 bg-green-500 p-1 rounded-full">
              <Activity className="h-4 w-4 text-white" />
            </span>
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl font-bold text-white mb-2">{user?.username || 'John Doe'}</h1>
            <p className="text-gray-400 mb-4">Forward • Manchester United</p>
            
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <Button variant="outline" size="sm">
                <Users className="h-4 w-4 mr-2" />
                Follow
              </Button>
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Match History
              </Button>
            </div>
          </div>
          
          <div className="flex flex-col gap-4">
            <div className="bg-gray-800 p-4 rounded-lg text-center">
              <p className="text-2xl font-bold text-green-400">93</p>
              <p className="text-sm text-gray-400">Overall Rating</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-1 bg-gray-900 p-1 rounded-lg mb-8 border border-green-500/20">
        <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')}>Overview</TabButton>
        <TabButton active={activeTab === 'stats'} onClick={() => setActiveTab('stats')}>Statistics</TabButton>
        <TabButton active={activeTab === 'achievements'} onClick={() => setActiveTab('achievements')}>Achievements</TabButton>
      </div>

      {/* Tab Content */}
      <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {activeTab === 'overview' && (
          <>
            <InfoCard title="Personal Information">
              <InfoRow label="Age" value="25" />
              <InfoRow label="Height" value="1.85m" />
              <InfoRow label="Weight" value="75kg" />
              <InfoRow label="Nationality" value="England" />
              <InfoRow label="Position" value="Forward" />
              <InfoRow label="Preferred Foot" value="Right" />
            </InfoCard>

            <InfoCard title="Contact Information">
              <InfoRow label="Email" value={user?.email || 'john.doe@example.com'} />
              <InfoRow label="Phone" value="+44 123 456 789" />
              <InfoRow label="Address" value="Manchester, UK" />
            </InfoCard>

            <InfoCard title="Team Information">
              <InfoRow label="Current Team" value="Manchester United" />
              <InfoRow label="Jersey Number" value="#10" />
              <InfoRow label="Contract Until" value="2025" />
              <InfoRow label="Market Value" value="€75M" />
            </InfoCard>
          </>
        )}

        {activeTab === 'stats' && (
          <>
            <StatCard title="Goals" value={stats.goals} icon={<Trophy />} />
            <StatCard title="Assists" value={stats.assists} icon={<Star />} />
            <StatCard title="Matches" value={stats.matches} icon={<Calendar />} />
            <StatCard title="Wins" value={stats.wins} icon={<Medal />} />
          </>
        )}

        {activeTab === 'achievements' && (
          <>
            {achievements.map((achievement) => (
              <AchievementCard key={achievement.id} {...achievement} />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

function TabButton({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
        active
          ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white'
          : 'text-gray-400 hover:text-white hover:bg-gray-800'
      }`}
    >
      {children}
    </button>
  );
}

function InfoCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
      <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-400">{label}</span>
      <span className="text-white font-medium">{value}</span>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string; value: number; icon: JSX.Element }) {
  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        <div className="text-green-400">{icon}</div>
      </div>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  );
}

function AchievementCard({ title, date, icon }: Achievement) {
  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
      <div className="flex items-center gap-4">
        <div className="bg-gray-800 p-3 rounded-lg">{icon}</div>
        <div>
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <p className="text-gray-400 text-sm">{new Date(date).toLocaleDateString()}</p>
        </div>
      </div>
    </div>
  );
}