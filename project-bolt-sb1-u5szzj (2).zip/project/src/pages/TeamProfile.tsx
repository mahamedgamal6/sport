import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Trophy, Star, Users, Mail, Phone, MapPin, Calendar, DollarSign, Edit, Upload, MessageCircle, LineChart, Camera } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/lib/store';

interface TeamStats {
  matches: number;
  wins: number;
  draws: number;
  losses: number;
  goalsFor: number;
  goalsAgainst: number;
}

interface TeamData {
  id: number;
  name: string;
  logo: string;
  coverImage: string;
  rating: number;
  coaches: string[];
  address: string;
  email: string;
  phone: string;
  championships: string[];
  marketValue: string;
  stats: TeamStats;
  isOwner: boolean;
}

const mockTeamData: TeamData = {
  id: 1,
  name: "Liverpool FC",
  logo: "https://images.unsplash.com/photo-1623796898129-f0df61d5c587?w=400&auto=format&fit=crop&q=60",
  coverImage: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&auto=format&fit=crop&q=60",
  rating: 4,
  coaches: ["Jürgen Klopp (Manager)", "Pepijn Lijnders (Assistant)", "Peter Krawietz (Assistant)"],
  address: "Anfield Road, Liverpool L4 0TH, United Kingdom",
  email: "info@liverpoolfc.com",
  phone: "+44 151 264 2500",
  championships: ["Premier League (19)", "Champions League (6)", "FA Cup (8)"],
  marketValue: "€853.5M",
  stats: {
    matches: 28,
    wins: 18,
    draws: 7,
    losses: 3,
    goalsFor: 61,
    goalsAgainst: 26
  },
  isOwner: true
};

export function TeamProfile() {
  const { id } = useParams();
  const [isEditing, setIsEditing] = useState(false);
  const [teamData, setTeamData] = useState<TeamData>(mockTeamData);
  const [activeTab, setActiveTab] = useState<'overview' | 'matches' | 'media'>('overview');

  const handleImageUpload = (type: 'cover' | 'logo') => {
    // Handle image upload logic here
    console.log(`Uploading ${type} image`);
  };

  const handleSave = () => {
    setIsEditing(false);
    // Handle save logic here
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-900 to-black">
      {/* Cover Image Section */}
      <div className="relative h-[300px]">
        <div className="absolute inset-0">
          <img
            src={teamData.coverImage}
            alt="Team Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-navy-900"></div>
        </div>
        
        {teamData.isOwner && (
          <button
            onClick={() => handleImageUpload('cover')}
            className="absolute top-4 right-4 p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
            title="Upload Cover Image"
          >
            <Camera className="h-6 w-6 text-white" />
          </button>
        )}
      </div>

      {/* Team Info Section */}
      <div className="max-w-7xl mx-auto px-4 -mt-32 relative z-10">
        <div className="bg-navy-900/90 rounded-2xl border border-yellow-500/20 backdrop-blur-sm p-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Logo Section */}
            <div className="relative">
              <div className="w-40 h-40 rounded-xl overflow-hidden border-4 border-yellow-500">
                <img
                  src={teamData.logo}
                  alt={teamData.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {teamData.isOwner && (
                <button
                  onClick={() => handleImageUpload('logo')}
                  className="absolute bottom-2 right-2 p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
                  title="Upload Logo"
                >
                  <Upload className="h-4 w-4 text-white" />
                </button>
              )}
            </div>

            {/* Team Details */}
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{teamData.name}</h1>
                  <div className="flex items-center gap-2 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${i < teamData.rating ? 'text-yellow-500' : 'text-gray-600'}`}
                        fill={i < teamData.rating ? 'currentColor' : 'none'}
                      />
                    ))}
                  </div>
                </div>
                {teamData.isOwner && (
                  <Button
                    onClick={() => setIsEditing(!isEditing)}
                    variant="outline"
                    className="border-yellow-500/20 hover:bg-yellow-500/10"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    {isEditing ? 'Save Changes' : 'Edit Profile'}
                  </Button>
                )}
              </div>

              {/* Team Information Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <InfoField
                  icon={Users}
                  label="Coaches"
                  value={teamData.coaches.join(", ")}
                  isEditing={isEditing}
                />
                <InfoField
                  icon={MapPin}
                  label="Address"
                  value={teamData.address}
                  isEditing={isEditing}
                />
                <InfoField
                  icon={Mail}
                  label="Email"
                  value={teamData.email}
                  isEditing={isEditing}
                />
                <InfoField
                  icon={Phone}
                  label="Phone"
                  value={teamData.phone}
                  isEditing={isEditing}
                />
                <InfoField
                  icon={Trophy}
                  label="Championships"
                  value={teamData.championships.join(", ")}
                  isEditing={isEditing}
                />
                <InfoField
                  icon={DollarSign}
                  label="Market Value"
                  value={teamData.marketValue}
                  isEditing={isEditing}
                />
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex space-x-1 mt-8">
            <TabButton
              active={activeTab === 'overview'}
              onClick={() => setActiveTab('overview')}
              icon={LineChart}
            >
              Overview
            </TabButton>
            <TabButton
              active={activeTab === 'matches'}
              onClick={() => setActiveTab('matches')}
              icon={Calendar}
            >
              Matches
            </TabButton>
            <TabButton
              active={activeTab === 'media'}
              onClick={() => setActiveTab('media')}
              icon={Camera}
            >
              Media
            </TabButton>
          </div>

          {/* Tab Content */}
          <div className="mt-6">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard label="Matches" value={teamData.stats.matches} />
                <StatCard label="Wins" value={teamData.stats.wins} />
                <StatCard label="Draws" value={teamData.stats.draws} />
                <StatCard label="Losses" value={teamData.stats.losses} />
              </div>
            )}
            {activeTab === 'matches' && (
              <div className="text-gray-400 text-center py-8">
                Match schedule coming soon
              </div>
            )}
            {activeTab === 'media' && (
              <div className="text-gray-400 text-center py-8">
                Media gallery coming soon
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-navy-900/90 border-t border-yellow-500/20 backdrop-blur-sm">
        <div className="max-w-md mx-auto flex justify-around py-4">
          <Button variant="ghost" className="flex flex-col items-center gap-1">
            <Users className="h-6 w-6" />
            <span className="text-xs">Squad</span>
          </Button>
          <Button variant="ghost" className="flex flex-col items-center gap-1">
            <MessageCircle className="h-6 w-6" />
            <span className="text-xs">Chat</span>
          </Button>
          <Button variant="ghost" className="flex flex-col items-center gap-1">
            <Trophy className="h-6 w-6" />
            <span className="text-xs">Trophies</span>
          </Button>
        </div>
      </div>
    </div>
  );
}

function InfoField({ icon: Icon, label, value, isEditing }: {
  icon: any;
  label: string;
  value: string;
  isEditing: boolean;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-gray-400">
        <Icon className="h-4 w-4" />
        <span>{label}</span>
      </div>
      {isEditing ? (
        <input
          type="text"
          value={value}
          className="w-full bg-navy-800/50 border border-yellow-500/20 rounded-lg px-3 py-2 text-white"
        />
      ) : (
        <p className="text-white">{value}</p>
      )}
    </div>
  );
}

function TabButton({ children, active, onClick, icon: Icon }: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
  icon: any;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
        active
          ? 'bg-yellow-500 text-black'
          : 'text-gray-400 hover:text-white hover:bg-white/10'
      }`}
    >
      <Icon className="h-4 w-4" />
      {children}
    </button>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-navy-800/50 rounded-xl p-4 border border-yellow-500/20">
      <p className="text-gray-400 text-sm">{label}</p>
      <p className="text-2xl font-bold text-white mt-1">{value}</p>
    </div>
  );
}