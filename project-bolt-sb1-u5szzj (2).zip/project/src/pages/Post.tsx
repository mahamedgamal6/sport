import { useState } from 'react';
import { Camera, Pencil, Users, MessageCircle, User, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export function Post() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      {/* Header Section */}
      <div className="relative h-[300px] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=1920"
            alt="Ronaldo"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-900"></div>
        </div>
        
        <div className="absolute top-4 right-4 flex space-x-4">
          <button className="p-2 bg-yellow-500 rounded-full hover:bg-yellow-400 transition-colors">
            <Pencil className="h-6 w-6 text-gray-900" />
          </button>
          <button className="p-2 bg-yellow-500 rounded-full hover:bg-yellow-400 transition-colors">
            <Camera className="h-6 w-6 text-gray-900" />
          </button>
        </div>

        <div className="absolute bottom-4 left-4 text-white">
          <h1 className="text-2xl font-bold mb-2">انشر خبر رياضي</h1>
          <p className="text-lg opacity-90">اهم مباريات اليوم</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-navy-900 rounded-xl p-6 shadow-xl border border-blue-500/20">
          {/* Post Form */}
          <div className="space-y-6">
            <div>
              <label className="block text-lg font-semibold text-white mb-2">Post Title</label>
              <input
                type="text"
                className="w-full bg-navy-800 border border-blue-500/20 rounded-lg p-3 text-white focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="Enter your post title"
              />
            </div>

            <div>
              <label className="block text-lg font-semibold text-white mb-2">Content</label>
              <textarea
                className="w-full bg-navy-800 border border-blue-500/20 rounded-lg p-3 text-white h-32 focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="Write your post content..."
              />
            </div>

            {/* Image Upload */}
            <div className="border-2 border-dashed border-blue-500/40 rounded-xl p-8 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="cursor-pointer flex flex-col items-center"
              >
                <Camera className="h-12 w-12 text-blue-400 mb-4" />
                <span className="text-blue-400">Click to upload image</span>
                <span className="text-gray-400 text-sm mt-2">PNG, JPG up to 10MB</span>
              </label>
              {selectedImage && (
                <img
                  src={selectedImage}
                  alt="Preview"
                  className="mt-4 max-h-64 mx-auto rounded-lg"
                />
              )}
            </div>

            {/* Tags */}
            <div>
              <label className="block text-lg font-semibold text-white mb-2">Tags</label>
              <input
                type="text"
                className="w-full bg-navy-800 border border-blue-500/20 rounded-lg p-3 text-white focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="Add tags (separated by commas)"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4">
              <Button variant="outline">Cancel</Button>
              <Button className="bg-gradient-to-r from-yellow-500 to-yellow-600">
                Publish Post
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-navy-900 border-t border-blue-500/20 p-4">
        <div className="max-w-md mx-auto flex justify-around">
          <button className="flex flex-col items-center text-yellow-500 hover:text-yellow-400 transition-colors">
            <Users className="h-6 w-6" />
            <span className="text-sm mt-1">Teams</span>
          </button>
          <button className="flex flex-col items-center text-yellow-500 hover:text-yellow-400 transition-colors">
            <MessageCircle className="h-6 w-6" />
            <span className="text-sm mt-1">Chat</span>
          </button>
          <button className="flex flex-col items-center text-yellow-500 hover:text-yellow-400 transition-colors">
            <User className="h-6 w-6" />
            <span className="text-sm mt-1">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}