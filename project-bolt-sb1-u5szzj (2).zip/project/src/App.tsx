import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Trophy, Users, ShoppingBag } from 'lucide-react';
import { Navbar } from './components/layout/Navbar';
import { Register } from './pages/Register';
import { Login } from './pages/Login';
import { Profile } from './pages/Profile';
import { Post } from './pages/Post';
import { Teams } from './pages/Teams';
import { TeamProfile } from './pages/TeamProfile';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black">
        <Navbar />
        <main className="pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/post" element={<Post />} />
            <Route path="/teams" element={<Teams />} />
            <Route path="/teams/:id" element={<TeamProfile />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function Home() {
  return (
    <div className="space-y-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <section className="text-center py-20 bg-gradient-to-r from-green-600 to-blue-600 rounded-3xl text-white shadow-xl">
        <h1 className="text-5xl font-bold mb-6">Welcome to Sports E-Gate</h1>
        <p className="text-xl max-w-2xl mx-auto mb-8">
          Your ultimate gateway to digital sports management, live cheering, and marketplace.
        </p>
        <div className="flex justify-center space-x-4">
          <a href="/register" className="bg-black text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-900 transition-colors border border-green-500">
            Get Started
          </a>
          <a href="/about" className="border border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors">
            Learn More
          </a>
        </div>
      </section>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <FeatureCard
          title="Digital Cheering Platform"
          description="Experience matches like never before with our revolutionary digital cheering system. Connect with fans worldwide in real-time."
          icon={Trophy}
        />
        <FeatureCard
          title="Tournament Central"
          description="Organize and participate in tournaments with our comprehensive management system. From local leagues to international cups."
          icon={Users}
        />
        <FeatureCard
          title="Sports Marketplace"
          description="Your one-stop shop for tickets, equipment, and club ownership opportunities. Secure, reliable, and instant."
          icon={ShoppingBag}
        />
      </div>
    </div>
  );
}

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

function FeatureCard({ title, description, icon: Icon }: FeatureCardProps) {
  return (
    <div className="bg-gray-900 p-8 rounded-xl shadow-md hover:shadow-lg transition-shadow border border-green-500/20">
      <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 p-3 rounded-lg w-fit mb-6">
        <Icon className="h-8 w-8 text-green-400" />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-white">{title}</h3>
      <p className="text-gray-300 leading-relaxed">{description}</p>
    </div>
  );
}

export default App;