import { Link } from 'react-router-dom';
import { PenSquare, Users, Trophy, MessageCircle, ShoppingBag, User, LogOut, FolderRoot as Football, ShoppingBasket as Basketball, Tent as Tennis } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/lib/store';
import { useState } from 'react';

export function Navbar() {
  const { isAuthenticated, user, logout } = useAuthStore();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showSportsMenu, setShowSportsMenu] = useState(false);
  const [selectedSport, setSelectedSport] = useState('football');

  const sports = [
    { id: 'football', icon: <Football className="h-6 w-6" />, label: 'Football' },
    { id: 'basketball', icon: <Basketball className="h-6 w-6" />, label: 'Basketball' },
    { id: 'tennis', icon: <Tennis className="h-6 w-6" />, label: 'Tennis' },
  ];

  return (
    <>
      {/* Main Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-black/40 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16 items-center">
            {/* Left Side - Sport Selector */}
            <div className="relative">
              <button
                onClick={() => setShowSportsMenu(!showSportsMenu)}
                className="p-2 rounded-full hover:bg-white/10 transition-colors text-white"
                title="Select Sport"
              >
                {sports.find(sport => sport.id === selectedSport)?.icon}
              </button>

              {showSportsMenu && (
                <div className="absolute top-full mt-2 w-48 bg-black/90 rounded-lg shadow-lg py-1 border border-white/20">
                  {sports.map((sport) => (
                    <button
                      key={sport.id}
                      onClick={() => {
                        setSelectedSport(sport.id);
                        setShowSportsMenu(false);
                      }}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-300 hover:bg-white/10"
                    >
                      <span className="h-4 w-4 mr-2">
                        {sport.icon}
                      </span>
                      {sport.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Center - Main Navigation Icons */}
            <div className="flex space-x-8">
              <NavLink to="/post" icon={PenSquare} title="Create Post" />
              <NavLink to="/teams" icon={Users} title="Teams" />
              <NavLink to="/matches" icon={Football} title="Matches" />
              <NavLink to="/tournaments" icon={Trophy} title="Tournaments" />
              <NavLink to="/chat" icon={MessageCircle} title="Chat" />
              <NavLink to="/store" icon={ShoppingBag} title="Store" />
            </div>

            {/* Right Side - User Menu */}
            <div className="relative">
              {isAuthenticated ? (
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="p-2 rounded-full hover:bg-white/10"
                    title={user?.username}
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-600 flex items-center justify-center">
                      <User className="h-5 w-5 text-black" />
                    </div>
                  </Button>

                  {showUserMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-black/90 rounded-lg shadow-lg py-1 border border-white/20">
                      <Link
                        to="/profile"
                        className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-white/10"
                        onClick={() => setShowUserMenu(false)}
                      >
                        <User className="h-4 w-4 mr-2" />
                        Profile
                      </Link>
                      <button
                        onClick={() => {
                          logout();
                          setShowUserMenu(false);
                        }}
                        className="flex items-center w-full px-4 py-2 text-sm text-gray-300 hover:bg-white/10"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-x-4">
                  <Link to="/login">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-white/20 hover:bg-white/10 text-white"
                    >
                      Login
                    </Button>
                  </Link>
                  <Link to="/register">
                    <Button 
                      size="sm" 
                      className="bg-yellow-500 hover:bg-yellow-600 text-black"
                    >
                      Register
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Spacer for fixed navbar */}
      <div className="h-16" />
    </>
  );
}

function NavLink({ to, icon: Icon, title }: { to: string; icon: any; title: string }) {
  return (
    <Link
      to={to}
      className="p-2 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors group relative"
      title={title}
    >
      <Icon className="h-6 w-6" />
      <span className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-black/90 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
        {title}
      </span>
    </Link>
  );
}