/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'navy': {
          800: 'rgba(0, 27, 64, 0.8)',
          900: 'rgba(0, 16, 38, 0.95)',
        },
      },
      backgroundImage: {
        'stadium': "url('https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80')",
      },
      boxShadow: {
        'glow': '0 0 15px rgba(255, 223, 0, 0.3)',
      },
    },
  },
  plugins: [],
};